#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(225u /*= 3.3957f */);
  lns16 b = lns16(233u /*= 3.5365f */);
  a = ((lns16(32714u /*= 0.7473f */) / lns16(32652u /*= 0.5343f */)) + (a * a));
  b = ((a - lns16(417u /*= 9.5900f */)) / b);
  result = lns16(262u /*= 4.1428f */);
  return 0;
}