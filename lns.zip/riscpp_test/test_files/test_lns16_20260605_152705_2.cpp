#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(0u /*= 1.0046f */);
  lns16 b = lns16(357u /*= 6.9425f */);
  a = ((lns16(291u /*= 4.8531f */) / lns16(116u /*= 1.8836f */)) / a);
  b = lns16(363u /*= 7.1494f */);
  result = (((lns16(61u /*= 1.3917f */) / b) / (a / b)) - b);
  return 0;
}