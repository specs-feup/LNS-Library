#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(409u /*= 9.1976f */);
  lns16 b = lns16(365u /*= 7.2351f */);
  a = lns16(392u /*= 8.3926f */);
  b = (a - a);
  result = b;
  return 0;
}