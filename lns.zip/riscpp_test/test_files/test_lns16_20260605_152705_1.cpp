#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(173u /*= 2.5566f */);
  lns16 b = lns16(346u /*= 6.5314f */);
  a = b;
  b = (a - (lns16(276u /*= 4.4725f */) * a));
  result = lns16(301u /*= 5.1132f */);
  return 0;
}