#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(349u);
  lns16 b = lns16(227u);
  a = ((lns16(420u) * b) - (a / b));
  b = ((lns16(98u) / b) - (lns16(355u) * lns16(375u)));
  result = (((b * a) / (a + a)) + ((lns16(213u) / lns16(281u)) / (b + lns16(388u))));
  return 0;
}