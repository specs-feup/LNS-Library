#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(172u);
  lns16 b = lns16(32688u);
  a = a;
  b = ((lns16(257u) * a) - a);
  result = (lns16(28u) * lns16(340u));
  return 0;
}