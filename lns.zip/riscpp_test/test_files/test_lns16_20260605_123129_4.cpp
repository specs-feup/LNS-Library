#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(320u);
  lns16 b = lns16(229u);
  a = a;
  b = ((lns16(338u) + a) / (lns16(205u) / b));
  result = (lns16(425u) / (lns16(386u) * lns16(202u)));
  return 0;
}