#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(408u);
  lns16 b = lns16(365u);
  a = ((a / b) * (b + b));
  b = lns16(297u);
  result = (((lns16(405u) + b) - (b * a)) + (lns16(32734u) / (a + a)));
  return 0;
}