#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(403u /*= 8.9011f */);
  lns16 b = lns16(412u /*= 9.3310f */);
  a = (lns16(374u /*= 7.5917f */) * (lns16(36u /*= 1.2193f */) + b));
  b = (a - (b / b));
  result = (((b - lns16(205u /*= 3.0413f */)) - (a * b)) - a);
  return 0;
}