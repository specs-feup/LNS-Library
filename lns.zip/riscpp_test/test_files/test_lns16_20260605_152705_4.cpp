#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(361u /*= 7.0942f */);
  lns16 b = lns16(309u /*= 5.3442f */);
  a = (lns16(188u /*= 2.7753f */) / b);
  b = lns16(8u /*= 1.0447f */);
  result = lns16(354u /*= 6.8153f */);
  return 0;
}