#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(411u /*= 9.2819f */);
  lns16 b = lns16(241u /*= 3.7029f */);
  a = (lns16(187u /*= 2.7567f */) + (b / b));
  b = ((lns16(330u /*= 5.9957f */) + a) * b);
  result = a;
  return 0;
}