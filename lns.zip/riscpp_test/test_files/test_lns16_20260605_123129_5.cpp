#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(310u);
  lns16 b = lns16(415u);
  a = ((lns16(332u) - b) - (b + a));
  b = a;
  result = (((lns16(282u) - lns16(320u)) - (b - b)) / ((b / b) - (b * a)));
  return 0;
}