#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(227u);
  lns16 b = lns16(370u);
  a = (a + lns16(278u));
  b = b;
  result = ((b / (b * lns16(117u))) / ((a * lns16(408u)) * b));
  return 0;
}