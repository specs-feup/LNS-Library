#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(32641u);
  lns16 b = lns16(32516u);
  a = ((lns16(130u) * b) / (a / b));
  b = ((lns16(32564u) + b) + lns16(99u));
  result = (((lns16(337u) / a) / (lns16(404u) + b)) + lns16(421u));
  return 0;
}