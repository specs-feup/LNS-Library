#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(32615u);
  lns16 b = lns16(32758u);
  a = (a + (lns16(32649u) + b));
  b = ((a * lns16(287u)) * a);
  result = (((lns16(102u) - b) * lns16(32640u)) * (b + lns16(320u)));
  return 0;
}