#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(370u);
  lns16 b = lns16(32500u);
  a = ((a * lns16(421u)) / lns16(200u));
  b = ((b + lns16(244u)) / (lns16(396u) * b));
  result = (a + (a / b));
  return 0;
}