#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(14u /*= 1.0828f */);
  lns16 b = lns16(314u /*= 5.5025f */);
  a = ((lns16(118u /*= 1.8951f */) - a) / a);
  b = ((b * b) / (b + b));
  result = ((a + (lns16(82u /*= 1.5591f */) * b)) - a);
  return 0;
}