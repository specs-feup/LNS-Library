#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(173u /*= 2.5527f */);
  lns16 b = lns16(346u /*= 6.5391f */);
  a = lns16(291u /*= 4.8415f */);
  b = ((lns16(388u /*= 8.2187f */) + lns16(238u /*= 3.6337f */)) + (b - lns16(88u /*= 1.6120f */)));
  result = lns16(250u /*= 3.8795f */);
  return 0;
}