#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(32570u);
  lns16 b = lns16(281u);
  a = b;
  b = ((lns16(32750u) + b) + (b + b));
  result = lns16(146u);
  return 0;
}