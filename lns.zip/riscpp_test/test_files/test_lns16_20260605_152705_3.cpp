#include "utils.h"
#include "lns.hpp"
volatile lns16 result;
extern "C" int my_main(void) {
  lns16 a = lns16(354u /*= 6.8339f */);
  lns16 b = lns16(215u /*= 3.2044f */);
  a = ((b + lns16(218u /*= 3.2596f */)) * (a - lns16(32398u /*= 0.1351f */)));
  b = a;
  result = a;
  return 0;
}